<?php


    $db['db_host']  =  "localhost";
    $db['db_user']  =  "root";
    $db['db_pass']  =  "creation11111";
    $db['db_name']  =  "tc_ewsd1";
//condition for making database to become a little bit secure

        foreach ($db as $key => $value) {

            define(strtoupper($key), $value);
        }

        $connection=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

?>